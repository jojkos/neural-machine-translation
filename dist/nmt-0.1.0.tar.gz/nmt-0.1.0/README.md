Neural machine translation package for python, keras/tensorflow

used in https://github.com/jojkos/master-thesis